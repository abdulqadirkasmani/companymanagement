<option <?php if($client_arr['city'] == 'Karachi'){ echo "selected"; } ?>>Karachi</option>
<option <?php if($client_arr['city'] == 'Lahore'){ echo "selected"; } ?>>Lahore</option>
<option <?php if($client_arr['city'] == 'Faisalabad'){ echo "selected"; } ?>>Faisalabad</option>
<option <?php if($client_arr['city'] == 'Rawalpindi'){ echo "selected"; } ?>>Rawalpindi</option>
<option <?php if($client_arr['city'] == 'Gujranwala'){ echo "selected"; } ?>>Gujranwala</option>
<option <?php if($client_arr['city'] == 'Peshawar'){ echo "selected"; } ?>>Peshawar</option>
<option <?php if($client_arr['city'] == 'Multan'){ echo "selected"; } ?>>Multan</option>
<option <?php if($client_arr['city'] == 'Hyderabad'){ echo "selected"; } ?>>Hyderabad</option>
<option <?php if($client_arr['city'] == 'Islamabad'){ echo "selected"; } ?>>Islamabad</option>
<option <?php if($client_arr['city'] == 'Quetta'){ echo "selected"; } ?>>Quetta</option>
<option <?php if($client_arr['city'] == 'Bahawalpur'){ echo "selected"; } ?>>Bahawalpur</option>
<option <?php if($client_arr['city'] == 'Sargodha'){ echo "selected"; } ?>>Sargodha</option>
<option <?php if($client_arr['city'] == 'Sialkot'){ echo "selected"; } ?>>Sialkot</option>
<option <?php if($client_arr['city'] == 'Sukkur'){ echo "selected"; } ?>>Sukkur</option>
<option <?php if($client_arr['city'] == 'Larkana'){ echo "selected"; } ?>>Larkana</option>
<option <?php if($client_arr['city'] == 'Rahim Yar Khan'){ echo "selected"; } ?>>Rahim Yar Khan</option>
<option <?php if($client_arr['city'] == 'Sheikhupura'){ echo "selected"; } ?>>Sheikhupura</option>
<option <?php if($client_arr['city'] == 'Jhang'){ echo "selected"; } ?>>Jhang</option>
<option <?php if($client_arr['city'] == 'Talagang'){ echo "selected"; } ?>>Talagang</option>
<option <?php if($client_arr['city'] == 'Dera Ghazi Khan'){ echo "selected"; } ?>>Dera Ghazi Khan</option>
<option <?php if($client_arr['city'] == 'Gujrat'){ echo "selected"; } ?>>Gujrat</option>
<option <?php if($client_arr['city'] == 'Sahiwal'){ echo "selected"; } ?>>Sahiwal</option>
<option <?php if($client_arr['city'] == 'Wah Cantonment'){ echo "selected"; } ?>>Wah Cantonment</option>
<option <?php if($client_arr['city'] == 'Mardan'){ echo "selected"; } ?>>Mardan</option>
<option <?php if($client_arr['city'] == 'Kasur'){ echo "selected"; } ?>>Kasur</option>
<option <?php if($client_arr['city'] == 'Okara'){ echo "selected"; } ?>>Okara</option>
<option <?php if($client_arr['city'] == 'Mingora'){ echo "selected"; } ?>>Mingora</option>
<option <?php if($client_arr['city'] == 'Nawabshah'){ echo "selected"; } ?>>Nawabshah</option>
<option <?php if($client_arr['city'] == 'Chiniot'){ echo "selected"; } ?>>Chiniot</option>
<option <?php if($client_arr['city'] == 'Kotri'){ echo "selected"; } ?>>Kotri</option>
<option <?php if($client_arr['city'] == 'Kāmoke'){ echo "selected"; } ?>>Kāmoke</option>
<option <?php if($client_arr['city'] == 'Hafizabad'){ echo "selected"; } ?>>Hafizabad</option>
<option <?php if($client_arr['city'] == 'Sadiqabad'){ echo "selected"; } ?>>Sadiqabad</option>
<option <?php if($client_arr['city'] == 'Mirpur Khas'){ echo "selected"; } ?>>Mirpur Khas</option>
<option <?php if($client_arr['city'] == 'Burewala'){ echo "selected"; } ?>>Burewala</option>
<option <?php if($client_arr['city'] == 'Kohat'){ echo "selected"; } ?>>Kohat</option>
<option <?php if($client_arr['city'] == 'Khanewal'){ echo "selected"; } ?>>Khanewal</option>
<option <?php if($client_arr['city'] == 'Dera Ismail Khan'){ echo "selected"; } ?>>Dera Ismail Khan</option>
<option <?php if($client_arr['city'] == 'Turbat'){ echo "selected"; } ?>>Turbat</option>
<option <?php if($client_arr['city'] == 'Muzaffargarh'){ echo "selected"; } ?>>Muzaffargarh</option>
<option <?php if($client_arr['city'] == 'Abbottabad'){ echo "selected"; } ?>>Abbottabad</option>
<option <?php if($client_arr['city'] == 'Mandi Bahauddin'){ echo "selected"; } ?>>Mandi Bahauddin</option>
<option <?php if($client_arr['city'] == 'Shikarpur'){ echo "selected"; } ?>>Shikarpur</option>
<option <?php if($client_arr['city'] == 'Jacobabad'){ echo "selected"; } ?>>Jacobabad</option>
<option <?php if($client_arr['city'] == 'Jhelum'){ echo "selected"; } ?>>Jhelum</option>
<option <?php if($client_arr['city'] == 'Khanpur'){ echo "selected"; } ?>>Khanpur</option>
<option <?php if($client_arr['city'] == 'Khairpur'){ echo "selected"; } ?>>Khairpur</option>
<option <?php if($client_arr['city'] == 'Khuzdar'){ echo "selected"; } ?>>Khuzdar</option>
<option <?php if($client_arr['city'] == 'Pakpattan'){ echo "selected"; } ?>>Pakpattan</option>
<option <?php if($client_arr['city'] == 'Hub'){ echo "selected"; } ?>>Hub</option>
<option <?php if($client_arr['city'] == 'Daska'){ echo "selected"; } ?>>Daska</option>
<option <?php if($client_arr['city'] == 'Gojra'){ echo "selected"; } ?>>Gojra</option>
<option <?php if($client_arr['city'] == 'Dadu'){ echo "selected"; } ?>>Dadu</option>
<option <?php if($client_arr['city'] == 'Muridke'){ echo "selected"; } ?>>Muridke</option>
<option <?php if($client_arr['city'] == 'Bahawalnagar'){ echo "selected"; } ?>>Bahawalnagar</option>
<option <?php if($client_arr['city'] == 'Samundri'){ echo "selected"; } ?>>Samundri</option>
<option <?php if($client_arr['city'] == 'Tando Allahyar'){ echo "selected"; } ?>>Tando Allahyar</option>
<option <?php if($client_arr['city'] == 'Tando Adam'){ echo "selected"; } ?>>Tando Adam</option>
<option <?php if($client_arr['city'] == 'Jaranwala'){ echo "selected"; } ?>>Jaranwala</option>
<option <?php if($client_arr['city'] == 'Chishtian'){ echo "selected"; } ?>>Chishtian</option>
<option <?php if($client_arr['city'] == 'Muzaffarabad'){ echo "selected"; } ?>>Muzaffarabad</option>
<option <?php if($client_arr['city'] == 'Attock'){ echo "selected"; } ?>>Attock</option>
<option <?php if($client_arr['city'] == 'Vehari'){ echo "selected"; } ?>>Vehari</option>
<option <?php if($client_arr['city'] == 'Kot Abdul Malik'){ echo "selected"; } ?>>Kot Abdul Malik</option>
<option <?php if($client_arr['city'] == 'Ferozwala'){ echo "selected"; } ?>>Ferozwala</option>
<option <?php if($client_arr['city'] == 'Chakwal'){ echo "selected"; } ?>>Chakwal</option>
<option <?php if($client_arr['city'] == 'Gujranwala Cantonment'){ echo "selected"; } ?>>Gujranwala Cantonment</option>
<option <?php if($client_arr['city'] == 'Kamalia'){ echo "selected"; } ?>>Kamalia</option>
<option <?php if($client_arr['city'] == 'Umerkot'){ echo "selected"; } ?>>Umerkot</option>
<option <?php if($client_arr['city'] == 'Ahmedpur East'){ echo "selected"; } ?>>Ahmedpur East</option>
<option <?php if($client_arr['city'] == 'Kot Addu'){ echo "selected"; } ?>>Kot Addu</option>
<option <?php if($client_arr['city'] == 'Wazirabad'){ echo "selected"; } ?>>Wazirabad</option>
<option <?php if($client_arr['city'] == 'Mansehra'){ echo "selected"; } ?>>Mansehra</option>
<option <?php if($client_arr['city'] == 'Layyah'){ echo "selected"; } ?>>Layyah</option>
<option <?php if($client_arr['city'] == 'Mirpur'){ echo "selected"; } ?>>Mirpur</option>
<option <?php if($client_arr['city'] == 'Swabi'){ echo "selected"; } ?>>Swabi</option>
<option <?php if($client_arr['city'] == 'Chaman'){ echo "selected"; } ?>>Chaman</option>
<option <?php if($client_arr['city'] == 'Taxila'){ echo "selected"; } ?>>Taxila</option>
<option <?php if($client_arr['city'] == 'Nowshera'){ echo "selected"; } ?>>Nowshera</option>
<option <?php if($client_arr['city'] == 'Khushab'){ echo "selected"; } ?>>Khushab</option>
<option <?php if($client_arr['city'] == 'Shahdadkot'){ echo "selected"; } ?>>Shahdadkot</option>
<option <?php if($client_arr['city'] == 'Mianwali'){ echo "selected"; } ?>>Mianwali</option>
<option <?php if($client_arr['city'] == 'Kabal'){ echo "selected"; } ?>>Kabal</option>
<option <?php if($client_arr['city'] == 'Lodhran'){ echo "selected"; } ?>>Lodhran</option>
<option <?php if($client_arr['city'] == 'Hasilpur'){ echo "selected"; } ?>>Hasilpur</option>
<option <?php if($client_arr['city'] == 'Charsadda'){ echo "selected"; } ?>>Charsadda</option>
<option <?php if($client_arr['city'] == 'Bhakkar'){ echo "selected"; } ?>>Bhakkar</option>
<option <?php if($client_arr['city'] == 'Badin'){ echo "selected"; } ?>>Badin</option>
<option <?php if($client_arr['city'] == 'Arif Wala'){ echo "selected"; } ?>>Arif Wala</option>
<option <?php if($client_arr['city'] == 'Ghotki'){ echo "selected"; } ?>>Ghotki</option>
<option <?php if($client_arr['city'] == 'Sambrial'){ echo "selected"; } ?>>Sambrial</option>
<option <?php if($client_arr['city'] == 'Jatoi'){ echo "selected"; } ?>>Jatoi</option>
<option <?php if($client_arr['city'] == 'Haroonabad'){ echo "selected"; } ?>>Haroonabad</option>
<option <?php if($client_arr['city'] == 'Daharki'){ echo "selected"; } ?>>Daharki</option>
<option <?php if($client_arr['city'] == 'Narowal'){ echo "selected"; } ?>>Narowal</option>
<option <?php if($client_arr['city'] == 'Tando Muhammad Khan'){ echo "selected"; } ?>>Tando Muhammad Khan</option>
<option <?php if($client_arr['city'] == 'Kamber Ali Khan'){ echo "selected"; } ?>>Kamber Ali Khan</option>
<option <?php if($client_arr['city'] == 'Mirpur Mathelo'){ echo "selected"; } ?>>Mirpur Mathelo</option>
<option <?php if($client_arr['city'] == 'Kandhkot'){ echo "selected"; } ?>>Kandhkot</option>
<option <?php if($client_arr['city'] == 'Bhalwal'){ echo "selected"; } ?>>Bhalwal</option>